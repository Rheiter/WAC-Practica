package les1.practicum6;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class ChatClient extends Application{

	@Override
	public void start(Stage primaryStage) {
		BorderPane root = new BorderPane();
		root.setPadding(new Insets(5));
		TextField textField = new TextField("asdasd");
		textField.setDisable(true);
		root.setCenter(textField);
		
		// Scene and stage
		Scene scene = new Scene(root);
		scene.getStylesheets().add("C:/Users/Pim/workspace/V1WAC/src/les1/practicum6/stylesheet.css");
		
		primaryStage.setTitle("Lekker kletsen!");
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
