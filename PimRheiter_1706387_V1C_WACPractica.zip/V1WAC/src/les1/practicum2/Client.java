package les1.practicum2;

import java.net.Socket;
import java.io.OutputStream;
import java.io.PrintWriter;

class Client {
  public static void main(String[] arg) throws Exception {
    Socket s = new Socket("145.89.152.28", 4711);
    OutputStream os = s.getOutputStream();
    PrintWriter pw = new PrintWriter(os);
    pw.write("hello\n");
    pw.close();
    s.close();
  }
}